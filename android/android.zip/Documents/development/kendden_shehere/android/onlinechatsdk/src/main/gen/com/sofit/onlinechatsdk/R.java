/*___Generated_by_IDEA___*/

package com.sofit.onlinechatsdk;

/* This stub is only used by the IDE. It is NOT the R class actually packed into the APK */
public final class R {
}