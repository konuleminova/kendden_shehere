package com.sofit.onlinechatsdk;

class Command {

    String command;

    Command(String command) {
        this.command = command;
    }
}